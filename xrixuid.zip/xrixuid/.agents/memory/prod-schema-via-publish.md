---
name: Production DB schema is applied by Replit Publish, not by code
description: How a new table/column reaches the production database after a dev schema change.
---

# Production schema changes go through the Publish flow, not code

For projects on Replit-managed PostgreSQL, the production DB schema is applied
automatically by Replit's **Publish** flow: on Publish, Replit diffs the
development schema against production, asks the user to resolve renames in the
Publish UI, and applies the diff to prod.

**Why:** This is the only supported path. The agent must NOT write code or
scripts to migrate prod — explicitly avoid custom migration scripts,
deploy-build hooks, and startup-time DDL (e.g. `CREATE TABLE IF NOT EXISTS` on
server boot). Those were considered for `track_events` and rejected.

**How to apply:** Make the schema change in dev (drizzle table + `pnpm --filter
@workspace/db run push`). That's sufficient — clicking Publish creates the
table/column in prod. If a deployed app errors with "relation/column does not
exist", the fix is to (re)publish, not to add DDL. See
`.local/skills/database/references/database-migrations-on-publish.md`.
