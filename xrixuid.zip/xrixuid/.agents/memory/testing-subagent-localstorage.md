---
name: Testing subagent localStorage reuse
description: The Playwright testing subagent reuses browser storage across runs, breaking data-import tests
---

# Testing subagent localStorage reuse

The Playwright-based `runTest()` testing subagent reuses the browser context / localStorage across multiple runs within a session, even when the plan says "[New Context]".

**Why it bites:** apps that dedupe imports against existing local state (e.g. UID import that skips already-present uids) will silently no-op on repeated test runs with the same input data. The import "completes" and shows the previously-imported cards, but fires NO new network calls (no tracking, no fetch), so server-side assertions see "0 new events" and you chase a non-existent backend bug.

**How to apply:** for any e2e test that imports/creates data, FIRST clear the app's local state inside the test (use the app's own clear-data control, e.g. a settings "clear all" button + accept the confirm dialog) before importing. Then assert. A clean-state run is the source of truth; a "0 events" result on a repeat run is almost always dedup, not a server bug. Confirm with `events.json` (ground truth) rather than `/tmp/logs` snapshots, which are stale between `refresh_all_logs` calls.
