---
name: .replit [nix].packages can't be removed programmatically
description: uninstallSystemDependencies no-ops on template-added nix packages; deploy nix layer is built from them
---

`uninstallSystemDependencies` can return `success: true` while doing nothing: the
packages listed in `.replit` under `[nix].packages` (e.g. a repl template's
`["cargo","eas-cli","libiconv","rustc"]`) are NOT removed — `.replit` is unchanged
(empty `git diff`), the binaries stay on PATH, and no nix rebuild happens. Direct edits
to `.replit`/`replit.nix` are blocked by the platform. Net: the agent cannot remove
these; only the user can, via the workspace **Dependencies** tool (System dependencies).

**Why it matters for deploys:** the autoscale build's `nix-0` layer is built from
`.replit [nix].packages`. Heavy, unused leftovers (Rust toolchain + `eas-cli`, which
drags in `nodejs-22`) make the *uncached* nix layer take ~9 min to build and have hit
"self-healing N corrupt nix store paths from binary cache" → build fails at
"Pushing nix-0 layer...". Removing the unused packages shrinks the layer to near-nothing
and eliminates the corrupt paths.

**How to apply:** if a Node-only repl still lists Rust/Expo nix packages from a removed
mobile app, don't burn turns retrying `uninstallSystemDependencies`. Tell the user to
open Dependencies → System dependencies and delete the unused entries, then re-publish.
`replit.nix` here only declares `unzip`; the real list lives in `.replit [nix].packages`.
