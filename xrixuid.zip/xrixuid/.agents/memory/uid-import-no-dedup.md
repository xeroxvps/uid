---
name: UID import keeps all lines
description: UID Operator import must keep every pasted line (no dedup/merge by UID)
---

# UID import keeps every pasted line

Rule: in artifacts/uid-web, the import flow must turn EVERY non-empty pasted
line into its own stored entry. Do not dedup within the paste and do not merge
into existing entries by UID. Repeated UIDs (same or different password) are all
kept and all shown.

**Why:** A user reported "700+ input korle list hoy 200" — pasting ~700 lines
only showed ~200. There was never a code cap; the collapse came from import-time
dedup-by-uid (a `seen` Set plus a reInput merge into existing entries). The user
explicitly confirmed (Banglish: "Jemon input koruk id dekate hobe sob") that
they want all pasted ids shown, not merged.

**How to apply:** Storage append uses `appendUIDs()` (appends all, no dedup) — not
a dedup helper. If you re-introduce any UID-based dedup/merge or a "re-input
updates existing password" behavior, you will reproduce the original bug.
`saveUIDs()` returns a boolean; import surfaces a destructive "Storage full"
toast when it returns false (localStorage quota), since the unbounded list can
eventually exceed quota.
