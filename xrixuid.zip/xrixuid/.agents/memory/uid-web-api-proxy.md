---
name: uid-web /api dev proxy
description: Why uid-web's vite dev server needs an /api proxy and how it's served in dev vs prod
---

# uid-web /api dev proxy

uid-web (the React+Vite web artifact) is served from TWO places:
- vite dev server (the preview pane and the Playwright testing browser load from this origin in dev).
- api-server's static build: `artifacts/api-server/start.sh` rebuilds uid-web into the api-server's static dir and serves it on the api-server port too.

The api-server (Express, port 8080) owns `/api/*` (admin tracking + FB fetch proxy to the python FB server).

**Rule:** vite's dev server must proxy `/api` to the api-server, or any browser `fetch("/api/...")` made from a page served by the vite origin returns the SPA HTML / 404 and never reaches the api-server.

**Why:** server-side `curl` to localhost:80 (unified router) or to the api-server directly always worked, which masked the bug — but the browser loads the SPA from vite's origin, so its same-origin `/api` calls hit vite, not the router. Without the proxy they silently failed (events never persisted, FB cards errored).

**How to apply:** keep `server.proxy["/api"] = { target: http://localhost:8080, changeOrigin: true }` in uid-web's vite.config. vite.config changes require a workflow RESTART (not HMR) to take effect. Production builds fresh from source so the proxy is dev-only and harmless there.
