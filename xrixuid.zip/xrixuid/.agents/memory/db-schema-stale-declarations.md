---
name: lib/db schema change → stale composite declarations
description: Why a consumer (e.g. api-server) reports "no exported member" from @workspace/db after a schema change even though runtime works.
---

# Stale composite-project declarations after a `lib/db` schema change

After adding/exporting a new table in `lib/db/src/schema/*`, `tsc --noEmit` in a
consumer package (e.g. `artifacts/api-server`) can fail with
`Module '@workspace/db' has no exported member '<X>'` while existing exports
(like `db`) still resolve, and **runtime works fine**.

**Why:** `lib/db` is a TypeScript *composite* project (`composite: true`,
`emitDeclarationOnly`, `outDir: dist`). Consumers reference it via project
references and typecheck against the emitted `lib/db/dist/**/*.d.ts`, NOT the
source. esbuild (the runtime build) reads the `src` via the package `exports`
map, so runtime sees the new export — but the `dist` `.d.ts` and
`tsconfig.tsbuildinfo` are stale from before the schema change (e.g. an old
`schema/index.d.ts` still says `export {};`).

**How to apply:** After any `lib/db` schema/export change, regenerate the
declarations before trusting/typechecking consumers:
`pnpm --filter @workspace/db exec tsc -b --force`. Deleting stale
`*.tsbuildinfo` first also helps. Do NOT run `find ... -name '*.tsbuildinfo'`
across the repo without pruning `node_modules` — it traverses node_modules and
times out.
