---
name: uid external single-host deploy
description: How UID Operator deploys as one Node service outside Replit, and why web-serving is gated.
---

On Replit, `uid-web` (Vite) and `api-server` (Express 5) are **separate artifacts** behind path routing (web at `/`, api at `/api`). For external hosts (Railway/Render/VPS) the app runs as **one Node service**: the Express server also serves the built web.

- The static-serving block in `api-server/src/app.ts` is **gated on `fs.existsSync(<webDir>/index.html)`** (default `../../uid-web/dist/public`, overridable via `WEB_DIST`). This keeps it **dormant on Replit** so the split-artifact routing is unchanged. Keep this gate.
- SPA fallback uses an `app.use` middleware that excludes `/api`, NOT `app.get('*')` — Express 5's path-to-regexp rejects a bare `*`.
- Deploy entry points: root scripts `build:deploy` (sets `PORT=3000 BASE_PATH=/` to satisfy `uid-web/vite.config.ts`, builds web then api) and `start:deploy`. `render.yaml` is a Render Blueprint (single web service + Postgres).
- Already external-DB-ready: everything reads `DATABASE_URL`. Create tables on a fresh DB with `pnpm --filter @workspace/db run push` (interactive) or `push-force` (non-interactive/CI).

**Why:** goal is Replit-independence (survive account issues) without breaking the working Replit setup; the existsSync gate is what lets the same code do both.
