---
name: Replit deploy runs uv sync on root Python manifests
description: Why a Node-only deploy can fail at "Installing packages" and how to fix it
---

Replit's automatic deploy "Installing packages" step runs `uv sync` whenever the repo
root has a `pyproject.toml` + `uv.lock` AND the `python-3.xx` module is present in
`.replit` — even if no service actually runs Python. `uv` targets the read-only nix
store, so a native-build dep (e.g. `bcrypt`) fails with "Permission denied creating
/nix/store/.../site-packages/...", killing the whole build.

**Why:** the package-install phase is implicit and module-driven, not derived from what
the deployed services run. A dead Python stack left in the repo silently blocks deploys.

**How to apply:** if the deployed app is Node-only, don't fight uv — remove the Python
footprint: delete root `pyproject.toml`/`uv.lock` (+ any stub `main.py`), uninstall the
`python-3.xx` module via the package tool (`uninstallProgrammingLanguage`), drop any
Python `[[services]]` from the artifact's `artifact.toml` (use the artifact tool, which
also auto-removes the matching workflow), and delete the orphaned `.py`/`.db` files.
Keep `postgresql-16` etc. if Node uses them. Verify each artifact's build runs with its
`[services.env]` (e.g. uid-web's vite build needs `PORT`/`BASE_PATH`) before publishing.
