---
name: uid-web mobile touch + clipboard
description: Why card actions use onClick (not onPointerDown) and why copy needs an execCommand fallback in uid-web
---

# Mobile touch actions and clipboard in uid-web

Rule 1 — actions on tappable list items must use `onClick`, never `onPointerDown`.
`onPointerDown` fires at touch START, so a vertical scroll that begins on a
button triggers that button. This caused "scrolling auto-copies" and "tapping a
UID opens an fb:// app-permission prompt". `onClick` only fires on a real tap
(browsers suppress it after a scroll), which is the correct gesture.

Rule 2 — with swipe-to-delete enabled, also guard against the synthetic click
that follows a horizontal swipe (a `didSwipe` ref set on touchend + an
`onClickCapture` that swallows the next click), or a swipe starting on a button
still fires it.

Rule 3 — clipboard copy must go through `lib/clipboard.ts:copyText()`, which
tries `navigator.clipboard` only in a secure context and falls back to a hidden
textarea + `document.execCommand('copy')`. Plain `navigator.clipboard.writeText`
fails silently in the Replit preview iframe / non-secure / some mobile browsers,
which is why copy "needed 2-3 taps". Set the success checkmark only when
`copyText` resolves true.

**Why:** These were real reported bugs on the published mobile app; the obvious
implementations (pointerdown for snappiness, bare clipboard API) break on mobile.

**How to apply:** Any new tappable control in a scrollable list, or any new copy
button, in uid-web (and similar mobile-styled artifacts) must follow these rules.

Rule 4 — the UIDCard ROOT element carries an inline `style.transform =
translateX(swipeX)` for swipe-to-delete. Never put any class on that root that
animates/sets `transform` (e.g. an entrance keyframe with `translateY` and
`animation-fill-mode: both`) — the filled animation value wins over the inline
transform and silently breaks the swipe. Entrance animations on the card root
must be opacity-only; animate transform on an inner wrapper if a "rise" is
needed.

**Why:** Caught in an architect review during a visual restyle — easy trap when
beautifying because the conflict is invisible until you actually swipe.

Performance note: the home list uses IntersectionObserver incremental rendering
(window of 40, +40 near bottom) instead of rendering all 700+ cards, and UIDCard
is `React.memo` with a CUSTOM comparator — required because `useUIDs` re-parses
localStorage on every update, giving every entry a new object identity (default
shallow memo would never hit). Stabilize callback props with useCallback.
